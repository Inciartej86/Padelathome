module.exports = {
  testEnvironment: 'node',
  testTimeout: 10000,
};
