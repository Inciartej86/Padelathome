// Fichero: public/reset-password.js

const API_BASE_URL = 'http://10.10.10.2:3000';

// Obtenemos referencias a los elementos del HTML
const resetForm = document.getElementById('reset-password-form');
const passwordInput = document.getElementById('password');
const confirmPasswordInput = document.getElementById('confirm-password');
const messageParagraph = document.getElementById('message');

// 1. Extraemos el token de la URL de la página
const urlParams = new URLSearchParams(window.location.search);
const token = urlParams.get('token');

// Si no hay token en la URL, mostramos un error
if (!token) {
  messageParagraph.textContent = 'Error: No se ha proporcionado un token válido.';
  messageParagraph.className = 'error-text';
}

resetForm.addEventListener('submit', async (event) => {
  event.preventDefault();

  const password = passwordInput.value;
  const confirmPassword = confirmPasswordInput.value;

  // 2. Verificamos que las contraseñas coinciden
  if (password !== confirmPassword) {
    messageParagraph.textContent = 'Las contraseñas no coinciden.';
    messageParagraph.className = 'error-text';
    return;
  }

  messageParagraph.textContent = 'Guardando...';
  messageParagraph.className = '';

  try {
    // 3. Hacemos la llamada a la API que ya teníamos construida
    const response = await fetch(`${API_BASE_URL}/api/auth/reset-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        token: token,
        newPassword: password
      })
    });

    const result = await response.json();
    if (!response.ok) {
      throw new Error(result.message || 'El token es inválido o ha expirado.');
    }

    // 4. Éxito
    messageParagraph.textContent = '¡Contraseña actualizada con éxito! Serás redirigido a la página de login en 3 segundos.';
    messageParagraph.className = 'success-text';

    setTimeout(() => {
      window.location.href = '/login.html';
    }, 3000);

  } catch (error) {
    messageParagraph.textContent = error.message;
    messageParagraph.className = 'error-text';
  }
});