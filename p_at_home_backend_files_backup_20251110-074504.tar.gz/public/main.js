// Fichero: public/main.js

if ('serviceWorker' in navigator) { // Comprueba si el navegador soporta Service Workers
  window.addEventListener('load', () => { // Espera a que toda la página cargue
    navigator.serviceWorker.register('/service-worker.js') // Intenta registrar el archivo
      .then(registration => {
        // Si tiene éxito, lo veremos en la consola
        console.log('Service Worker registrado con éxito con el scope:', registration.scope);
      })
      .catch(error => {
        // Si falla, también veremos el error en la consola
        console.log('Fallo en el registro del Service Worker:', error);
      });
  });
}