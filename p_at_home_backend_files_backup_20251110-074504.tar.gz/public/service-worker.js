// Fichero: public/service-worker.js

const CACHE_NAME = 'padelathome-cache-v1';
// Lista de archivos que queremos guardar en caché para que la app funcione offline
const urlsToCache = [
  '/',
  '/login.html',
  '/dashboard.html',
  '/admin.html',
  '/login.js',
  '/dashboard.js',
  '/admin.js',
  '/images/icon-192x192.png',
  '/images/icon-512x512.png'
  // Podríamos añadir un /style.css aquí si lo tuviéramos
];

// Evento 'install': Se dispara cuando el service worker se instala por primera vez.
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Cache abierta');
        return cache.addAll(urlsToCache);
      })
  );
});

// Evento 'fetch': Se dispara cada vez que la aplicación hace una petición (ej. pide un .js, un .css, una imagen).
self.addEventListener('fetch', event => {
  // Ignoramos las peticiones a la API, esas siempre deben ir a la red
  if (event.request.url.includes('/api/')) {
    return;
  }

  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Si encontramos el archivo en la caché, lo devolvemos desde ahí.
        if (response) {
          return response;
        }
        // Si no, hacemos la petición a la red como siempre.
        return fetch(event.request);
      })
  );
});
