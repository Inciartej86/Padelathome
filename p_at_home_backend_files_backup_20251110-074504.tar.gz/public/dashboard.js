const API_BASE_URL = '';
const authToken = localStorage.getItem('authToken');

// --- 1. REFERENCIAS A ELEMENTOS DEL DOM ---
const notificationContainer = document.getElementById('notification-container');
const welcomeMessage = document.getElementById('welcome-message');
const adminPanelBtn = document.getElementById('admin-panel-btn');
const logoutButton = document.getElementById('logout-button');
const myBookingContainer = document.getElementById('my-booking-container');
const courtSelect = document.getElementById('court-select');
const calendarContainer = document.getElementById('weekly-calendar-container');
const weekDatesTitle = document.getElementById('week-dates-title');
const prevWeekBtn = document.getElementById('prev-week-btn');
const nextWeekBtn = document.getElementById('next-week-btn');
// Modales
const bookingModalOverlay = document.getElementById('modal-overlay');
const bookingModalTime = document.getElementById('modal-time');
const bookingModalOptions = document.getElementById('modal-options-container');
const openMatchCheckbox = document.getElementById('open-match-checkbox');
const bookingModalCancelBtn = document.getElementById('modal-cancel-btn');
const waitlistModalOverlay = document.getElementById('waitlist-modal-overlay');
const waitlistJoinBtn = document.getElementById('waitlist-join-btn');
const waitlistCancelBtn = document.getElementById('waitlist-cancel-btn');
const joinMatchModalOverlay = document.getElementById('join-match-modal-overlay');
const joinMatchTime = document.getElementById('join-match-time');
const joinMatchParticipants = document.getElementById('join-match-participants');
const joinMatchConfirmBtn = document.getElementById('join-match-confirm-btn');
const joinMatchCancelBtn = document.getElementById('join-match-cancel-btn');


// --- 2. DATOS GLOBALES ---
let currentDisplayedDate = new Date();
let weeklyScheduleData = {};

    // --- 3. FUNCIONES AUXILIARES ---
    const formatDate = (date) => new Date(date).toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' });
    const formatTime = (date) => new Date(date).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit', hour12: false });

    const showNotification = (message, type = 'info') => {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        notificationContainer.appendChild(notification);
        setTimeout(() => {
            notification.remove();
        }, 5000);
    };

    const fetchApi = async (url, options = {}) => {
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${authToken}`,
            ...options.headers,
        };

        const response = await fetch(`${API_BASE_URL}${url}`, { ...options, headers });

        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.message || 'Error en la petición a la API');
        }
        return data;
    };

    // --- 4. FUNCIONES PRINCIPALES ---

    const fetchAndPopulateCourts = async () => {
        try {
            const courts = await fetchApi('/api/courts');
            courtSelect.innerHTML = ''; // Limpiar opciones existentes
            courts.forEach(court => {
                const option = document.createElement('option');
                option.value = court.id;
                option.textContent = court.name;
                courtSelect.appendChild(option);
            });
        } catch (error) {
            console.error("Error en fetchAndPopulateCourts:", error);
            showNotification('No se pudieron cargar las pistas. Inténtalo de nuevo.', 'error');
        }
    };

    const fetchUserProfile = async () => {
        try {
            const user = await fetchApi('/api/users/me');
            welcomeMessage.textContent = `Bienvenido, ${user.name}!`;
            if (user.role === 'admin') {
                adminPanelBtn.style.display = 'inline-block';
            }
        } catch (error) {
            console.error("Error en fetchUserProfile:", error);
        }
    };

    const fetchMyBooking = async () => {
        try {
            const booking = await fetchApi('/api/bookings/me');
            if (booking) {
                const isOwner = booking.participation_type === 'owner';
                const buttonHtml = isOwner 
                    ? `<button id="cancel-booking-btn" data-booking-id="${booking.id}">Cancelar Reserva Completa</button>`
                    : `<button id="leave-match-btn" data-booking-id="${booking.id}">Abandonar Partida</button>`;
                myBookingContainer.innerHTML = `<p><strong>Pista:</strong> ${booking.court_name}<br><strong>Día:</strong> ${new Date(booking.start_time).toLocaleString('es-ES')}</p>${buttonHtml}`;
            } else {
                myBookingContainer.innerHTML = '<p>No tienes ninguna reserva activa.</p>';
            }
        } catch (error) {
            console.error('Error en fetchMyBooking:', error);
            myBookingContainer.innerHTML = '<p style="color:red;">No se pudo obtener tu reserva.</p>';
        }
    };

    const renderWeeklyCalendar = async (date) => {
        calendarContainer.innerHTML = '<p>Cargando calendario...</p>';
        const dateString = new Date(date).toISOString().split('T')[0];
        try {
            const data = await fetchApi(`/api/schedule/week?courtId=${courtSelect.value}&date=${dateString}`);
            weeklyScheduleData = data.schedule;
            weekDatesTitle.textContent = `Semana del ${formatDate(data.weekStart)} al ${formatDate(data.weekEnd)}`;
            
            const grid = document.createElement('div');
            grid.className = 'calendar-grid';
            const days = ['Horas', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
            days.forEach(day => {
                const dayCell = document.createElement('div'); dayCell.className = 'grid-cell day-header';
                dayCell.textContent = day; grid.appendChild(dayCell);
            });

            const weekDays = Object.keys(weeklyScheduleData).sort();
            if (weekDays.length === 0) throw new Error("No se recibieron datos del calendario.");
            
            const timeSlots = weeklyScheduleData[weekDays[0]];
            timeSlots.forEach((slot, timeIndex) => {
                const timeCell = document.createElement('div');
                timeCell.className = 'grid-cell time-header';
                timeCell.textContent = formatTime(new Date(slot.startTime));
                grid.appendChild(timeCell);

                weekDays.forEach(dayString => {
                    const currentSlotData = weeklyScheduleData[dayString][timeIndex];
                    const slotCell = document.createElement('div');
                    slotCell.className = 'grid-cell slot';
                    slotCell.dataset.starttime = currentSlotData.startTime;
                    
                    let cellContent = '';
                    switch (currentSlotData.status) {
                        case 'available':
                            slotCell.classList.add('available');
                            cellContent = 'Libre';
                            break;
                        case 'booked':
                            slotCell.classList.add('booked');
                            slotCell.dataset.waitlistable = 'true';
                            cellContent = 'Ocupado';
                            break;
                        case 'open_match_available':
                            slotCell.classList.add('open-match');
                            slotCell.dataset.action = 'join_match';
                            slotCell.dataset.bookingId = currentSlotData.bookingId;
                            slotCell.dataset.participants = currentSlotData.participants;
                            slotCell.dataset.maxParticipants = currentSlotData.maxParticipants;
                            cellContent = `Partida Abierta (${currentSlotData.participants}/${currentSlotData.maxParticipants})`;
                            break;
                        case 'open_match_full':
                            slotCell.classList.add('booked');
                            cellContent = `Partida Llena`;
                            break;
                        case 'blocked':
                            slotCell.classList.add('blocked');
                            cellContent = currentSlotData.reason || 'Bloqueado';
                            break;
                    }
                    slotCell.innerHTML = `<span>${cellContent}</span>`;
                    grid.appendChild(slotCell);
                });
            });
            
            calendarContainer.innerHTML = '';
            calendarContainer.appendChild(grid);
            const legend = document.createElement('div');
            legend.className = 'legend';
            legend.innerHTML = `<div><span class="color-box available"></span> Disponible</div> <div><span class="color-box open-match"></span> Partida Abierta</div> <div><span class="color-box booked"></span> Ocupado</div>`;
            calendarContainer.appendChild(legend);
        } catch (error) {
            console.error("Error al renderizar el calendario:", error);
            calendarContainer.innerHTML = `<p style="color:red;">${error.message}</p>`;
        }
    };

    const showBookingModal = (target) => {
        const startTime = target.dataset.starttime;
        const dateString = startTime.split('T')[0];
        const timeIndex = weeklyScheduleData[dateString]?.findIndex(slot => slot.startTime === startTime);
        if (timeIndex === -1 || !weeklyScheduleData[dateString]) return;

        const daySlots = weeklyScheduleData[dateString];
        const availableDurations = [];
        if (daySlots[timeIndex + 1]?.status === 'available') availableDurations.push(60);
        if (daySlots[timeIndex + 1]?.status === 'available' && daySlots[timeIndex + 2]?.status === 'available') availableDurations.push(90);
        if (availableDurations.length === 0) {
            showNotification('No hay suficiente tiempo continuo para una reserva completa (mínimo 60 min).', 'error');
            return;
        }

        openMatchCheckbox.checked = false;
        bookingModalTime.textContent = formatTime(new Date(startTime));
        bookingModalOptions.innerHTML = '';
        availableDurations.forEach(duration => {
            const button = document.createElement('button');
            button.textContent = `${duration} min`;
            button.dataset.duration = duration;
            button.dataset.startTime = startTime;
            bookingModalOptions.appendChild(button);
        });

        bookingModalOverlay.addEventListener('click', (event) => { if (event.target === bookingModalOverlay) bookingModalOverlay.classList.add('hidden'); });
        bookingModalCancelBtn.addEventListener('click', () => { bookingModalOverlay.classList.add('hidden'); });
        bookingModalOptions.addEventListener('click', handleBookingModalAction);

        bookingModalOverlay.classList.remove('hidden');
    };

    const showWaitlistModal = (target) => {
        const startTime = target.dataset.starttime;
        waitlistJoinBtn.dataset.courtid = courtSelect.value;
        waitlistJoinBtn.dataset.starttime = startTime;

        waitlistModalOverlay.addEventListener('click', (event) => { if (event.target.id === 'waitlist-modal-overlay') waitlistModalOverlay.classList.add('hidden'); });
        waitlistCancelBtn.addEventListener('click', () => { waitlistModalOverlay.classList.add('hidden'); });
        waitlistJoinBtn.addEventListener('click', handleWaitlistModalAction);

        waitlistModalOverlay.classList.remove('hidden');
    };
    
    const showOpenMatchModal = (target) => {
        const { bookingId, participants, maxParticipants, starttime } = target.dataset;
        joinMatchTime.textContent = new Date(starttime).toLocaleString('es-ES');
        joinMatchParticipants.textContent = `${participants}/${maxParticipants}`;
        joinMatchConfirmBtn.dataset.bookingId = bookingId;

        joinMatchModalOverlay.addEventListener('click', (event) => { if (event.target.id === 'join-match-modal-overlay') joinMatchModalOverlay.classList.add('hidden'); });
        joinMatchCancelBtn.addEventListener('click', () => { joinMatchModalOverlay.classList.add('hidden'); });
        joinMatchConfirmBtn.addEventListener('click', handleJoinMatchAction);

        joinMatchModalOverlay.classList.remove('hidden');
    };

    // --- 5. MANEJADORES DE EVENTOS (HANDLERS) ---
    const handleCalendarClick = (event) => {
        const target = event.target.closest('.slot');
        if (!target) return;

        if (target.classList.contains('available')) {
            showBookingModal(target);
        } else if (target.dataset.waitlistable === 'true') {
            showWaitlistModal(target);
        } else if (target.dataset.action === 'join_match') {
            showOpenMatchModal(target);
        }
    };
    
    const handleMyBookingActions = async (event) => {
        const target = event.target;
        const bookingId = target.dataset.bookingId;
        if (!bookingId) return;

        let url = '';
        let method = 'DELETE';
        let confirmMessage = '';

        if (target.id === 'cancel-booking-btn') {
            url = `/api/bookings/${bookingId}`;
            confirmMessage = '¿Estás seguro de que quieres cancelar esta reserva para TODOS los jugadores?';
        } else if (target.id === 'leave-match-btn') {
            url = `/api/matches/${bookingId}/leave`;
            confirmMessage = '¿Estás seguro de que quieres abandonar esta partida?';
        } else {
            return;
        }

        if (!confirm(confirmMessage)) return;

        try {
            const data = await fetchApi(url, { method });
            showNotification(data.message || 'Acción completada con éxito.', 'success');
            fetchMyBooking();
            renderWeeklyCalendar(currentDisplayedDate);
        } catch (error) {
            showNotification(error.message, 'error');
        }
    };
    
    const handleBookingModalAction = async (event) => {
        if (event.target.tagName !== 'BUTTON') return;
        const { startTime, duration } = event.target.dataset;
        const body = {
            courtId: courtSelect.value,
            startTime: startTime,
            durationMinutes: parseInt(duration),
            isOpenMatch: openMatchCheckbox.checked,
            maxParticipants: openMatchCheckbox.checked ? 4 : null
        };
        try {
            await fetchApi('/api/bookings', {
                method: 'POST',
                body: JSON.stringify(body)
            });
            showNotification('¡Reserva creada con éxito!', 'success');
            bookingModalOverlay.classList.add('hidden');
            renderWeeklyCalendar(currentDisplayedDate);
            fetchMyBooking();
        } catch (error) {
            showNotification(`Error al reservar: ${error.message}`, 'error');
        }
    };

    const handleWaitlistModalAction = async () => {
        const { courtid, starttime } = waitlistJoinBtn.dataset;
        const slotEndTime = new Date(new Date(starttime).getTime() + 30 * 60000).toISOString();
        try {
            await fetchApi('/api/waiting-list', {
                method: 'POST',
                body: JSON.stringify({ courtId: parseInt(courtid), slotStartTime: starttime, slotEndTime: slotEndTime })
            });
            showNotification('¡Te has apuntado a la lista de espera con éxito!', 'success');
            waitlistModalOverlay.classList.add('hidden');
        } catch(error) {
            showNotification(error.message, 'error');
        }
    };
    
    const handleJoinMatchAction = async (event) => {
        const bookingId = event.target.dataset.bookingId;
        if (!bookingId || bookingId === 'undefined') {
            showNotification('Error: No se pudo identificar la partida. El ID es inválido.', 'error');
            return;
        }
        try {
            await fetchApi(`/api/matches/${bookingId}/join`, {
                method: 'POST'
            });
            showNotification('¡Te has unido a la partida con éxito!', 'success');
            joinMatchModalOverlay.classList.add('hidden');
            renderWeeklyCalendar(currentDisplayedDate);
        } catch(error) {
            showNotification(error.message, 'error');
        }
    };
    
    // --- 6. LÓGICA DE INICIO Y ASIGNACIÓN DE EVENTOS ---
    
    const initializePage = async () => {
        if (!authToken) {
            showNotification('Debes iniciar sesión para ver esta página.', 'error');
            window.location.href = '/login.html';
            return;
        }

        // Carga de datos inicial
        await fetchAndPopulateCourts();
        fetchUserProfile();
        fetchMyBooking();
        renderWeeklyCalendar(currentDisplayedDate);

        // Listeners de navegación y acciones generales
        logoutButton.addEventListener('click', () => { localStorage.removeItem('authToken'); window.location.href = '/login.html'; });
        adminPanelBtn.addEventListener('click', () => { window.location.href = '/admin.html'; });
        prevWeekBtn.addEventListener('click', () => { currentDisplayedDate.setDate(currentDisplayedDate.getDate() - 7); renderWeeklyCalendar(currentDisplayedDate); });
        nextWeekBtn.addEventListener('click', () => { currentDisplayedDate.setDate(currentDisplayedDate.getDate() + 7); renderWeeklyCalendar(currentDisplayedDate); });
        courtSelect.addEventListener('change', () => renderWeeklyCalendar(currentDisplayedDate));
        
        // Listeners principales para delegación de eventos
        myBookingContainer.addEventListener('click', handleMyBookingActions);
        calendarContainer.addEventListener('click', handleCalendarClick);
        
    };

    // Envuelve toda la inicialización en un listener que se asegura de que el HTML está listo
    document.addEventListener('DOMContentLoaded', initializePage);