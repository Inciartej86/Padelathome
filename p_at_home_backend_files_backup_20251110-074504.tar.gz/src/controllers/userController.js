const pool = require('../config/database');

const getUserProfile = async (req, res) => {
  try {
    const userId = req.user.id; 
    
    // Consulta SQL actualizada con JOIN para obtener la dirección
    const userResult = await pool.query(
      `SELECT 
         u.id, u.name, u.email, u.floor, u.door, u.phone_number, u.role, u.account_status,
         b.address as building_address 
       FROM 
         users u 
       LEFT JOIN 
         buildings b ON u.building_id = b.id 
       WHERE 
         u.id = $1`,
      [userId]
    );

    if (userResult.rows.length > 0) {
      res.json(userResult.rows[0]);
    } else {
      res.status(404).json({ message: 'Usuario no encontrado.' });
    }
  } catch (error) {
    console.error('Error al obtener perfil de usuario:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

module.exports = {
  getUserProfile,
};