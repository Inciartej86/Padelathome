const pool = require('../config/database');
const { addMinutes } = require('date-fns');
const sendEmail = require('../services/emailService');
const ics = require('ics');
const crypto = require('crypto');

const createBooking = async (req, res) => {
  const userId = req.user.id;
  const { courtId, startTime, durationMinutes, isOpenMatch, maxParticipants } = req.body;

  if (!courtId || !startTime || !durationMinutes) {
    return res.status(400).json({ message: 'Se requiere courtId, startTime y durationMinutes.' });
  }
  const bookingStartTime = new Date(startTime);
  const bookingEndTime = addMinutes(bookingStartTime, durationMinutes);
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const activeBookingResult = await client.query("SELECT id FROM bookings WHERE user_id = $1 AND status = 'confirmed' AND end_time > (NOW() AT TIME ZONE 'UTC')", [userId]);
    if (activeBookingResult.rows.length > 0 && !isOpenMatch) {
      throw new Error('Ya tienes una reserva personal activa.');
    }
    const [bookingsResult, blockedResult] = await Promise.all([
        client.query("SELECT start_time, end_time FROM bookings WHERE court_id = $1 AND status = 'confirmed' AND start_time < $2 AND end_time > $3", [courtId, bookingEndTime, bookingStartTime]),
        client.query("SELECT start_time, end_time FROM blocked_periods WHERE court_id = $1 AND start_time < $2 AND end_time > $3", [courtId, bookingEndTime, bookingStartTime])
    ]);
    if (bookingsResult.rows.length > 0 || blockedResult.rows.length > 0) {
        throw new Error('El horario seleccionado ya no está disponible.');
    }
    
    const newBookingResult = await client.query(
      "INSERT INTO bookings (court_id, user_id, start_time, end_time, is_open_match, max_participants, auto_cancel_hours_before) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *",
      [courtId, userId, bookingStartTime, bookingEndTime, !!isOpenMatch, isOpenMatch ? maxParticipants : null, isOpenMatch ? 6 : null]
    );
    const newBooking = newBookingResult.rows[0];

    if (newBooking.is_open_match) {
      await client.query("INSERT INTO match_participants (booking_id, user_id) VALUES ($1, $2)", [newBooking.id, userId]);
    }

    const userResult = await client.query("SELECT name, email FROM users WHERE id = $1", [userId]);
    const courtResult = await pool.query("SELECT name FROM courts WHERE id = $1", [courtId]);
    
    await client.query('COMMIT');

    // Enviar email después de confirmar la transacción
    const user = userResult.rows[0];
    const courtName = courtResult.rows[0].name;
    const event = {
      title: 'Reserva de Pista de Pádel',
      description: `Pista: ${courtName}\nReservado por: ${user.name}\n\nNos veremos en la pista, ¡no olvides dar lo mejor!`,
      start: [bookingStartTime.getUTCFullYear(), bookingStartTime.getUTCMonth() + 1, bookingStartTime.getUTCDate(), bookingStartTime.getUTCHours(), bookingStartTime.getUTCMinutes()],
      end: [bookingEndTime.getUTCFullYear(), bookingEndTime.getUTCMonth() + 1, bookingEndTime.getUTCDate(), bookingEndTime.getUTCHours(), bookingEndTime.getUTCMinutes()],
      status: 'CONFIRMED',
      organizer: { name: 'Padel@Home Admin', email: process.env.SMTP_USER },
      attendees: [{ name: user.name, email: user.email, rsvp: true, role: 'REQ-PARTICIPANT' }]
    };
    
    const { error, value } = ics.createEvent(event);
    if (!error) {
        sendEmail({
            to: user.email,
            subject: `Confirmación de Reserva en Padel@Home para el ${bookingStartTime.toLocaleDateString('es-ES')}`,
            html: `<h3>¡Hola, ${user.name}!</h3><p>Tu reserva ha sido confirmada. Adjuntamos un evento de calendario.</p>`,
            attachments: [{ filename: 'invitacion.ics', content: value, contentType: 'text/calendar' }]
        });
    }

    res.status(201).json(newBooking);

  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error al crear la reserva:', error);
    res.status(400).json({ message: error.message || 'Error al procesar la reserva.' });
  } finally {
    client.release();
  }
};

const getMyBooking = async (req, res) => {
  try {
    const userId = req.user.id;
    const query = `
      SELECT b.*, c.name as court_name, 'owner' as participation_type
      FROM bookings b
      JOIN courts c ON b.court_id = c.id
      WHERE b.user_id = $1 AND b.status = 'confirmed' AND b.end_time > (NOW() AT TIME ZONE 'UTC')
      UNION
      SELECT b.*, c.name as court_name, 'participant' as participation_type
      FROM bookings b
      JOIN courts c ON b.court_id = c.id
      JOIN match_participants mp ON b.id = mp.booking_id
      WHERE mp.user_id = $1 AND b.user_id != $1 AND b.status = 'confirmed' AND b.end_time > (NOW() AT TIME ZONE 'UTC')
      ORDER BY start_time ASC
      LIMIT 1;
    `;
    const result = await pool.query(query, [userId]);
    if (result.rows.length > 0) {
      res.json(result.rows[0]);
    } else {
      res.json(null);
    }
  } catch (error) {
    console.error('Error al obtener mi reserva:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

const cancelMyBooking = async (req, res) => {
  const client = await pool.connect();
  try {
    const userId = req.user.id;
    const { bookingId } = req.params;
    
    await client.query('BEGIN');

    const result = await client.query(
      "UPDATE bookings SET status = 'cancelled_by_user' WHERE id = $1 AND user_id = $2 AND status = 'confirmed' RETURNING *",
      [bookingId, userId]
    );
    if (result.rowCount === 0) {
      throw new Error('No se encontró una reserva activa para cancelar o no tienes permiso para hacerlo.');
    }
    const cancelledBooking = result.rows[0];

    // Disparador de la Lista de Espera
    const waitingListResult = await client.query(
      `SELECT wle.id, wle.user_id, u.name as user_name, u.email as user_email, wle.slot_start_time
       FROM waiting_list_entries wle
       JOIN users u ON wle.user_id = u.id
       WHERE wle.court_id = $1 AND wle.slot_start_time = $2 AND wle.status = 'waiting'
       ORDER BY wle.requested_at ASC
       LIMIT 1`,
      [cancelledBooking.court_id, cancelledBooking.start_time]
    );

    if (waitingListResult.rows.length > 0) {
      const luckyUser = waitingListResult.rows[0];
      const confirmationToken = crypto.randomBytes(32).toString('hex');
      const expires_at = new Date(Date.now() + 30 * 60 * 1000); // 30 minutos

      await client.query(
        "UPDATE waiting_list_entries SET status = 'notified', confirmation_token = $1, notification_expires_at = $2, notification_sent_at = NOW() WHERE id = $3",
        [confirmationToken, expires_at, luckyUser.id]
      );
      
      const confirmationUrl = `http://${process.env.PUBLIC_IP || '10.10.10.2'}:3000/confirm-booking.html?token=${confirmationToken}`;
      sendEmail({
        to: luckyUser.user_email,
        subject: '¡Un hueco se ha liberado en Padel@Home!',
        html: `<h3>¡Hola, ${luckyUser.user_name}!</h3><p>Se ha liberado el horario por el que estabas esperando.</p><p>Tienes <strong>30 minutos</strong> para confirmar la reserva.</p><a href="${confirmationUrl}">Confirmar mi Reserva</a>`
      });
      console.log(`Notificación de lista de espera enviada al usuario ${luckyUser.user_id}`);
    }

    await client.query('COMMIT');
    res.json({ message: 'Reserva cancelada exitosamente.' });

  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error al cancelar la reserva:', error);
    res.status(400).json({ message: error.message || 'Error interno del servidor.' });
  } finally {
    client.release();
  }
};

module.exports = {
  createBooking,
  getMyBooking,
  cancelMyBooking,
};