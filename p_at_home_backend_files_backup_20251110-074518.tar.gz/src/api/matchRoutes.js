const express = require('express');
const router = express.Router();
const { getOpenMatches, joinOpenMatch, leaveOpenMatch } = require('../controllers/matchController');
const { protect } = require('../middleware/authMiddleware');

// GET /api/matches/open - Obtener todas las partidas abiertas disponibles
router.get('/open', protect, getOpenMatches);

// POST /api/matches/:bookingId/join - Unirse a una partida abierta
router.post('/:bookingId/join', protect, joinOpenMatch);

// DELETE /api/matches/:bookingId/leave - Abandonar una partida abierta
router.delete('/:bookingId/leave', protect, leaveOpenMatch);

module.exports = router;