const pool = require('../config/database');

const getOpenMatches = async (req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT 
        b.id, 
        b.court_id, 
        c.name as court_name,
        b.start_time, 
        b.end_time, 
        b.max_participants,
        COUNT(mp.user_id) as current_participants,
        b.user_id as organizer_id,
        u.name as organizer_name
      FROM bookings b
      JOIN courts c ON b.court_id = c.id
      LEFT JOIN match_participants mp ON b.id = mp.booking_id
      JOIN users u ON b.user_id = u.id
      WHERE b.is_open_match = TRUE 
        AND b.status = 'confirmed' 
        AND b.end_time > NOW()
      GROUP BY b.id, c.name, u.name
      ORDER BY b.start_time ASC;
    `);
    res.json(rows);
  } catch (error) {
    console.error('Error al obtener partidas abiertas:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

const joinOpenMatch = async (req, res) => {
  const userId = req.user.id;
  const { bookingId } = req.params;
  if (!bookingId || isNaN(parseInt(bookingId))) {
    return res.status(400).json({ message: 'El ID de la partida proporcionado no es válido.' });
  }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    // Bloquear la fila de la reserva para evitar condiciones de carrera
    const bookingResult = await client.query("SELECT * FROM bookings WHERE id = $1 AND status = 'confirmed' FOR UPDATE", [bookingId]);
    if (bookingResult.rows.length === 0) throw new Error('Esta partida ya no existe o ha sido cancelada.');
    
    const booking = bookingResult.rows[0];
    if (!booking.is_open_match) throw new Error('Esta reserva no es una partida abierta.');
    if (booking.user_id === userId) throw new Error('No puedes unirte a tu propia partida, ya eres el organizador.');

    // Contar participantes actuales
    const participantsResult = await client.query("SELECT user_id FROM match_participants WHERE booking_id = $1", [bookingId]);
    if (participantsResult.rows.length >= booking.max_participants) throw new Error('Esta partida ya está completa.');
    
    // Verificar si el usuario ya está unido
    const isAlreadyJoined = participantsResult.rows.some(p => p.user_id == userId);
    if (isAlreadyJoined) throw new Error('Ya te has unido a esta partida.');

    // Añadir participante
    await client.query("INSERT INTO match_participants (booking_id, user_id) VALUES ($1, $2)", [bookingId, userId]);
    await client.query('COMMIT');
    res.status(200).json({ message: 'Te has unido a la partida con éxito.' });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error al unirse a la partida:', error);
    res.status(400).json({ message: error.message || 'Error al procesar la solicitud.' });
  } finally {
    client.release();
  }
};

const leaveOpenMatch = async (req, res) => {
  const userId = req.user.id;
  const { bookingId } = req.params;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Obtener y bloquear la reserva
    const bookingResult = await client.query("SELECT * FROM bookings WHERE id = $1 FOR UPDATE", [bookingId]);
    if (bookingResult.rowCount === 0) {
      throw new Error("Partida no encontrada.");
    }
    const booking = bookingResult.rows[0];

    // Eliminar al participante
    const participantResult = await client.query("DELETE FROM match_participants WHERE booking_id = $1 AND user_id = $2 RETURNING *", [bookingId, userId]);
    if (participantResult.rowCount === 0) {
      throw new Error("No estás unido a esta partida.");
    }

    // Obtener participantes restantes
    const remainingParticipantsResult = await client.query("SELECT user_id FROM match_participants WHERE booking_id = $1 ORDER BY created_at ASC", [bookingId]);
    const remainingParticipants = remainingParticipantsResult.rows;

    // Si el que se va es el organizador
    if (booking.user_id === userId) {
      if (remainingParticipants.length > 0) {
        // Asignar nuevo organizador al siguiente en la lista
        const newOrganizerId = remainingParticipants[0].user_id;
        await client.query("UPDATE bookings SET user_id = $1 WHERE id = $2", [newOrganizerId, bookingId]);
        // Eliminar al nuevo organizador de la tabla de participantes (ya es el dueño de la reserva)
        await client.query("DELETE FROM match_participants WHERE booking_id = $1 AND user_id = $2", [bookingId, newOrganizerId]);
      } else {
        // Si no quedan participantes, se cancela la reserva
        await client.query("UPDATE bookings SET status = 'cancelled' WHERE id = $1", [bookingId]);
      }
    }

    // Lógica de cancelación si no está llena a 6h del inicio (FR-OPEN-03)
    const hoursUntilMatch = (new Date(booking.start_time) - new Date()) / (1000 * 60 * 60);
    if (hoursUntilMatch > 6 && remainingParticipants.length < booking.max_participants) {
        // Se cancela la partida
        await client.query("UPDATE bookings SET status = 'cancelled' WHERE id = $1", [bookingId]);
        // Aquí se podría añadir la lógica para notificar a los participantes
    }

    await client.query('COMMIT');
    res.json({ message: 'Has abandonado la partida correctamente.' });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error al abandonar la partida:', error);
    res.status(400).json({ message: error.message });
  } finally {
    client.release();
  }
};

module.exports = {
  getOpenMatches,
  joinOpenMatch,
  leaveOpenMatch,
};