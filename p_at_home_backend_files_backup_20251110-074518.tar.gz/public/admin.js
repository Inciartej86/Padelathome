const API_BASE_URL = '';
const authToken = localStorage.getItem('authToken');

// --- 1. REFERENCIAS A ELEMENTOS DEL DOM ---
const adminNameSpan = document.getElementById('admin-name');
const logoutButton = document.getElementById('logout-button');
// Usuarios
const userTableBody = document.getElementById('user-table-body');
const inviteUserForm = document.getElementById('invite-user-form');
const inviteBuildingSelect = document.getElementById('invite-building');
// Pistas
const courtForm = document.getElementById('court-form');
const courtFormTitle = document.getElementById('court-form-title');
const courtIdInput = document.getElementById('court-id');
const courtNameInput = document.getElementById('court-name');
const courtDescriptionInput = document.getElementById('court-description');
const courtIsActiveDiv = document.getElementById('court-active-div');
const courtIsActiveCheckbox = document.getElementById('court-is-active');
const cancelEditBtn = document.getElementById('cancel-edit-btn');
const courtsListContainer = document.getElementById('courts-list-container');
// Bloqueos
const createBlockForm = document.getElementById('create-block-form');
const blockCourtSelect = document.getElementById('block-court-select');
const blockStartTimeInput = document.getElementById('block-start-time');
const blockEndTimeInput = document.getElementById('block-end-time');
const blockReasonInput = document.getElementById('block-reason');
const blocksListContainer = document.getElementById('blocks-list-container');
// Edificios
const buildingForm = document.getElementById('building-form');
const buildingFormTitle = document.getElementById('building-form-title');
const buildingIdInput = document.getElementById('building-id');
const buildingAddressInput = document.getElementById('building-address');
const buildingDescriptionInput = document.getElementById('building-description');
const cancelBuildingEditBtn = document.getElementById('cancel-building-edit-btn');
const buildingsListContainer = document.getElementById('buildings-list-container');
// Ajustes
const settingsForm = document.getElementById('settings-form');
const openTimeInput = document.getElementById('setting-open-time');
const closeTimeInput = document.getElementById('setting-close-time');
const advanceDaysInput = document.getElementById('setting-advance-days');
const gapOptimizationCheckbox = document.getElementById('setting-gap-optimization');

const notificationContainer = document.getElementById('notification-container');

// --- 2. DATOS GLOBALES ---
let allCourtsData = [];
let allBuildings = [];

// --- 3. DEFINICIÓN DE FUNCIONES ---

const showNotification = (message, type = 'info') => {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notificationContainer.appendChild(notification);
    setTimeout(() => {
        notification.remove();
    }, 5000);
};

const fetchApi = async (url, options = {}) => {
    const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${authToken}`,
        ...options.headers,
    };

    const response = await fetch(`${API_BASE_URL}${url}`, { ...options, headers });

    const data = await response.json();
    if (!response.ok) {
        throw new Error(data.message || 'Error en la petición a la API');
    }
    return data;
};

async function initializeAdminPanel() {
  try {
    const user = await fetchApi('/api/users/me');
    if (user.role !== 'admin') {
      showNotification('Acceso denegado. No eres administrador.', 'error');
      window.location.href = '/dashboard.html';
      return;
    }
    adminNameSpan.textContent = user.name;
    // Cargar todos los datos del panel
    fetchAndDisplayUsers();
    fetchAndDisplayCourts();
    fetchAndDisplayBuildings();
    fetchAndDisplayBlockedPeriods();
    fetchAndDisplaySettings();
  } catch (error) {
    console.error(error);
    localStorage.removeItem('authToken');
    showNotification('Sesión inválida. Por favor, inicia sesión de nuevo.', 'error');
    window.location.href = '/login.html';
  }
}

async function fetchAndDisplayUsers() {
  try {
    const users = await fetchApi('/api/admin/users');
    userTableBody.innerHTML = '';
    users.forEach(user => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${user.id}</td>
        <td>${user.name}</td>
        <td>${user.email}</td>
        <td>${user.account_status}</td>
        <td>
          ${user.account_status === 'pending_approval' ? `<button class="approve-btn" data-userid="${user.id}">Aprobar</button>` : ''}
          ${user.account_status === 'active' ? `<button class="deactivate-btn" data-userid="${user.id}">Desactivar</button>` : ''}
          ${user.account_status === 'inactive' ? `<button class="activate-btn" data-userid="${user.id}">Activar</button>` : ''}
        </td>`;
      userTableBody.appendChild(row);
    });
  } catch (error) {
    console.error('Error al obtener usuarios:', error);
    userTableBody.innerHTML = '<tr><td colspan="5" style="color:red;">Error al cargar los usuarios.</td></tr>';
  }
}

async function fetchAndDisplayCourts() {
    try {
        const courts = await fetchApi('/api/courts');
        allCourtsData = courts;
        blockCourtSelect.innerHTML = '';
        courts.forEach(court => {
            if (court.is_active) {
                const option = document.createElement('option');
                option.value = court.id;
                option.textContent = court.name;
                blockCourtSelect.appendChild(option);
            }
        });
        courtsListContainer.innerHTML = '';
        const courtList = document.createElement('ul');
        if (courts.length === 0) {
            courtList.innerHTML = '<li>No hay pistas creadas en el sistema.</li>';
        } else {
            courts.forEach(court => {
                const listItem = document.createElement('li');
                listItem.innerHTML = `<strong>${court.name}</strong> (ID: ${court.id}) - Estado: ${court.is_active ? '<strong>Activa</strong>' : '<span style="color:red;">Inactiva</span>'}<br><em>${court.description || 'Sin descripción.'}</em><br><button class="edit-court-btn" data-courtid="${court.id}">Editar</button>`;
                courtList.appendChild(listItem);
            });
        }
        courtsListContainer.appendChild(courtList);
    } catch (error) {
        console.error('Error al obtener pistas:', error);
        courtsListContainer.innerHTML = '<p style="color:red;">Error al cargar la información de las pistas.</p>';
    }
}

async function fetchAndDisplayBuildings() {
  try {
    const buildings = await fetchApi('/api/admin/buildings');
    allBuildings = buildings;
    inviteBuildingSelect.innerHTML = '';
    if (buildings.length > 0) {
      buildings.forEach(building => {
        const option = document.createElement('option');
        option.value = building.id;
        option.textContent = building.address;
        inviteBuildingSelect.appendChild(option);
      });
    }
    buildingsListContainer.innerHTML = '';
    const list = document.createElement('ul');
    if (buildings.length === 0) {
      list.innerHTML = '<li>No hay edificios creados.</li>';
    } else {
      buildings.forEach(building => {
        const item = document.createElement('li');
        item.innerHTML = `<strong>${building.address}</strong> (ID: ${building.id})<br><em>${building.description || 'Sin descripción'}</em><br><button class="edit-building-btn" data-buildingid="${building.id}">Editar</button><button class="delete-building-btn" data-buildingid="${building.id}">Eliminar</button>`;
        list.appendChild(item);
      });
    }
    buildingsListContainer.appendChild(list);
  } catch (error) {
    console.error('Error al obtener edificios:', error);
    buildingsListContainer.innerHTML = '<p style="color:red;">Error al cargar los edificios.</p>';
  }
}

async function fetchAndDisplayBlockedPeriods() {
  try {
    const blockedPeriods = await fetchApi('/api/admin/blocked-periods');
    blocksListContainer.innerHTML = '';
    const list = document.createElement('ul');
    if (blockedPeriods.length === 0) {
      list.innerHTML = '<li>No hay bloqueos futuros programados.</li>';
    } else {
      blockedPeriods.forEach(block => {
        const item = document.createElement('li');
        item.innerHTML = `<strong>Pista:</strong> ${block.court_name} <br><strong>Desde:</strong> ${new Date(block.start_time).toLocaleString('es-ES')} <br><strong>Hasta:</strong> ${new Date(block.end_time).toLocaleString('es-ES')} <br><strong>Motivo:</strong> ${block.reason || 'N/A'}<button class="delete-block-btn" data-blockid="${block.id}">Eliminar</button>`;
        list.appendChild(item);
      });
    }
    blocksListContainer.appendChild(list);
  } catch (error) {
    console.error('Error al obtener bloqueos:', error);
    blocksListContainer.innerHTML = '<p style="color:red;">Error al cargar los bloqueos.</p>';
  }
}

async function fetchAndDisplaySettings() {
  try {
    const settings = await fetchApi('/api/admin/settings');
    openTimeInput.value = settings.operating_open_time || '08:00';
    closeTimeInput.value = settings.operating_close_time || '22:00';
    advanceDaysInput.value = settings.booking_advance_days || '7';
    gapOptimizationCheckbox.checked = settings.enable_booking_gap_optimization === 'true';
  } catch (error) {
    console.error('Error al obtener los ajustes:', error);
    showNotification('No se pudieron cargar los ajustes.', 'error');
  }
}

function resetCourtForm() {
  courtFormTitle.textContent = 'Crear Nueva Pista';
  courtForm.reset();
  courtIdInput.value = '';
  courtIsActiveDiv.style.display = 'none';
  cancelEditBtn.style.display = 'none';
}

function resetBuildingForm() {
  buildingFormTitle.textContent = 'Añadir Nuevo Edificio';
  buildingForm.reset();
  buildingIdInput.value = '';
  cancelBuildingEditBtn.style.display = 'none';
}

async function handleUserAction(event) {
  const target = event.target;
  const userId = target.dataset.userid;
  if (!userId) return;
  let actionUrl = '';
  let actionMethod = 'PUT';
  let actionPayload = {};
  if (target.classList.contains('approve-btn')) {
    actionUrl = `/api/admin/users/${userId}/approve`;
  } else if (target.classList.contains('deactivate-btn')) {
    actionUrl = `/api/admin/users/${userId}/status`;
    actionPayload = { status: 'inactive' };
  } else if (target.classList.contains('activate-btn')) {
    actionUrl = `/api/admin/users/${userId}/status`;
    actionPayload = { status: 'active' };
  } else {
    return;
  }
  if (!confirm('¿Estás seguro de que quieres realizar esta acción?')) return;
  try {
    const data = await fetchApi(actionUrl, {
      method: actionMethod,
      body: Object.keys(actionPayload).length > 0 ? JSON.stringify(actionPayload) : null,
    });
    showNotification('Acción completada con éxito.', 'success');
    fetchAndDisplayUsers();
  } catch(error) {
    showNotification(error.message, 'error');
  }
}

// --- 4. LÓGICA DE INICIO Y EVENT LISTENERS ---

if (!authToken) {
  showNotification('Acceso denegado.', 'error');
  window.location.href = '/login.html';
} else {
  // Primero, definimos la lógica que se ejecutará al cargar la página
  initializeAdminPanel();

  // Luego, asignamos todos los "escuchadores" de eventos
  logoutButton.addEventListener('click', () => {
    localStorage.removeItem('authToken');
    window.location.href = '/login.html';
  });
  
  userTableBody.addEventListener('click', handleUserAction);

  courtsListContainer.addEventListener('click', (event) => {
    if (event.target.classList.contains('edit-court-btn')) {
        const courtId = event.target.dataset.courtid;
        const courtToEdit = allCourtsData.find(c => c.id == courtId);
        if (courtToEdit) {
            courtFormTitle.textContent = 'Editar Pista';
            courtIdInput.value = courtToEdit.id;
            courtNameInput.value = courtToEdit.name;
            courtDescriptionInput.value = courtToEdit.description;
            courtIsActiveDiv.style.display = 'block';
            courtIsActiveCheckbox.checked = courtToEdit.is_active;
            cancelEditBtn.style.display = 'inline-block';
            courtForm.scrollIntoView({ behavior: 'smooth' });
        }
    }
  });



  // Event listener para el formulario de pistas (Crear y Editar)
  courtForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const courtId = courtIdInput.value;
    const isEditing = !!courtId;
    
    const url = isEditing ? `/api/courts/${courtId}` : '/api/courts';
    const method = isEditing ? 'PUT' : 'POST';

    const body = {
      name: courtNameInput.value,
      description: courtDescriptionInput.value,
    };
    if (isEditing) {
      body.is_active = courtIsActiveCheckbox.checked;
    }

    try {
      await fetchApi(url, {
        method: method,
        body: JSON.stringify(body)
      });
      
      showNotification(`Pista ${isEditing ? 'actualizada' : 'creada'} con éxito.`, 'success');
      resetCourtForm();
      fetchAndDisplayCourts();
    } catch (error) {
      showNotification(error.message, 'error');
    }
  });
createBlockForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    await fetchApi('/api/admin/blocked-periods', {
      method: 'POST',
      body: JSON.stringify({
        courtId: blockCourtSelect.value,
        startTime: blockStartTimeInput.value,
        endTime: blockEndTimeInput.value,
        reason: blockReasonInput.value
      })
    });
    showNotification('Bloqueo creado con éxito.', 'success');
    createBlockForm.reset();
    fetchAndDisplayBlockedPeriods(); // Refrescamos la lista de bloqueos
  } catch(error) {
    showNotification(error.message, 'error');
  }
});

// Listener para la lista de bloqueos (para los botones de eliminar)
blocksListContainer.addEventListener('click', async (event) => {
  if (event.target.classList.contains('delete-block-btn')) {
    const blockId = event.target.dataset.blockid;
    if (!confirm(`¿Estás seguro de que quieres eliminar el bloqueo ID ${blockId}?`)) return;

    try {
      await fetchApi(`/api/admin/blocked-periods/${blockId}`, {
        method: 'DELETE'
      });
      showNotification('Bloqueo eliminado con éxito.', 'success');
      fetchAndDisplayBlockedPeriods(); // Refrescamos la lista
    } catch(error) {
      showNotification(error.message, 'error');
    }
  }
});
  
  // Listener para el formulario de edificios (maneja tanto Crear como Editar)
buildingForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const buildingId = buildingIdInput.value;
  const isEditing = !!buildingId;
  
  const url = isEditing ? `/api/admin/buildings/${buildingId}` : '/api/admin/buildings';
  const method = isEditing ? 'PUT' : 'POST';

  try {
    await fetchApi(url, {
      method,
      body: JSON.stringify({
        address: buildingAddressInput.value,
        description: buildingDescriptionInput.value
      })
    });
    
    showNotification(`Edificio ${isEditing ? 'actualizado' : 'creado'} con éxito.`, 'success');
    resetBuildingForm(); // Limpiamos el formulario
    fetchAndDisplayBuildings(); // Refrescamos la lista
  } catch (error) {
    showNotification(error.message, 'error');
  }
});

// Listener para la lista de edificios (para los botones de Editar y Eliminar)
buildingsListContainer.addEventListener('click', async (event) => {
  const target = event.target;
  const buildingId = target.dataset.buildingid;
  if (!buildingId) return; // Si no se hizo clic en un botón con ID, no hacemos nada

  // Acción para el botón "Editar"
  if (target.classList.contains('edit-building-btn')) {
    const buildingToEdit = allBuildings.find(b => b.id == buildingId);
    if (buildingToEdit) {
      buildingFormTitle.textContent = 'Editar Edificio';
      buildingIdInput.value = buildingToEdit.id;
      buildingAddressInput.value = buildingToEdit.address;
      buildingDescriptionInput.value = buildingToEdit.description;
      cancelBuildingEditBtn.style.display = 'inline-block';
      buildingForm.scrollIntoView({ behavior: 'smooth' }); // Lleva al usuario al formulario
    }
  }
  // Acción para el botón "Eliminar"
  else if (target.classList.contains('delete-building-btn')) {
    if (!confirm(`¿Estás seguro de que quieres eliminar el edificio ID ${buildingId}?`)) return;

    try {
        await fetchApi(`/api/admin/buildings/${buildingId}`, {
            method: 'DELETE'
        });
        showNotification('Edificio eliminado.', 'success');
        fetchAndDisplayBuildings(); // Refrescamos la lista
    } catch (error) {
        showNotification(error.message, 'error');
    }
  }
});

// Listener para el botón de cancelar edición
cancelBuildingEditBtn.addEventListener('click', resetBuildingForm);
  // Listener para guardar los ajustes
settingsForm.addEventListener('submit', async (event) => {
  event.preventDefault();

  const settingsToUpdate = {
    operating_open_time: openTimeInput.value,
    operating_close_time: closeTimeInput.value,
    booking_advance_days: advanceDaysInput.value,
    enable_booking_gap_optimization: gapOptimizationCheckbox.checked.toString() // 'true' o 'false'
  };

  if (!confirm('¿Estás seguro de que quieres guardar estos nuevos ajustes?')) return;

  try {
    await fetchApi('/api/admin/settings', {
      method: 'PUT',
      body: JSON.stringify(settingsToUpdate)
    });
    showNotification('Ajustes guardados con éxito.', 'success');
  } catch (error) {
    showNotification(`Error al guardar los ajustes: ${error.message}`, 'error');
  }
});  inviteUserForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const payload = {
    name: document.getElementById('invite-name').value,
    email: document.getElementById('invite-email').value,
    building_id: document.getElementById('invite-building').value,
    floor: document.getElementById('invite-floor').value,
    door: document.getElementById('invite-door').value,
  };

  try {
    await fetchApi('/api/admin/users/invite', {
      method: 'POST',
      body: JSON.stringify(payload)
    });

    showNotification('Invitación enviada con éxito.', 'success');
    inviteUserForm.reset();
    fetchAndDisplayUsers(); // Refrescamos la lista de usuarios
  } catch (error) {
    showNotification(error.message, 'error');
  }
});
  // Event listener para el botón de cancelar edición
  cancelEditBtn.addEventListener('click', resetCourtForm);
};