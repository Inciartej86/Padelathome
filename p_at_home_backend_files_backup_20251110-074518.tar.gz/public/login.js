// Fichero: public/login.js

// 1. Obtenemos referencias a los elementos del HTML
const loginForm = document.getElementById('login-form');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const errorMessage = document.getElementById('error-message');

// 2. Añadimos un "escuchador" para el evento 'submit' del formulario
loginForm.addEventListener('submit', async (event) => {
  // Prevenimos el comportamiento por defecto del formulario (que recargaría la página)
  event.preventDefault(); 

  // 3. Obtenemos los valores de los inputs
  const email = emailInput.value;
  const password = passwordInput.value;
  
  // Limpiamos mensajes de error anteriores
  errorMessage.textContent = '';

  try {
    // 4. Usamos la API 'fetch' para llamar a nuestro endpoint de login en el backend
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, password }),
    });

    const data = await response.json();

    // 5. Manejamos la respuesta del servidor
    if (!response.ok) {
      // Si la respuesta no es exitosa (ej. 401, 403), mostramos el error
      throw new Error(data.message || 'Error al iniciar sesión');
    }

    // ¡Éxito! Guardamos el token y redirigimos
    console.log('Login exitoso!', data);
    
    localStorage.setItem('authToken', data.token);
    // Redirigimos al dashboard
    window.location.href = '/dashboard.html';

  } catch (error) {
    // Si hubo un error en la llamada fetch o en la respuesta, lo mostramos
    errorMessage.textContent = error.message;
  }
});
