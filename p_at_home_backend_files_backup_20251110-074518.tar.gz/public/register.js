// Fichero: public/register.js

const API_BASE_URL = 'http://10.10.10.2:3000';

const registerForm = document.getElementById('register-form');
const messageParagraph = document.getElementById('message');

registerForm.addEventListener('submit', async (event) => {
  event.preventDefault();

  // Recogemos los datos del formulario usando el objeto FormData
  const formData = new FormData(registerForm);
  const data = Object.fromEntries(formData.entries());

  // Extraemos los valores de los inputs por su 'id' para más claridad
  data.name = document.getElementById('name').value;
  data.email = document.getElementById('email').value;
  data.password = document.getElementById('password').value;
  data.building = document.getElementById('building').value;
  data.floor = document.getElementById('floor').value;
  data.door = document.getElementById('door').value;
  data.phone_number = document.getElementById('phone_number').value;

  messageParagraph.textContent = 'Enviando registro...';
  messageParagraph.style.color = 'black';

  try {
    const response = await fetch(`${API_BASE_URL}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.message || 'Error al registrar la cuenta.');
    }

    // Éxito
    registerForm.reset();
    messageParagraph.style.color = 'green';
    messageParagraph.textContent = '¡Registro exitoso! Un administrador debe aprobar tu cuenta antes de que puedas iniciar sesión. Serás redirigido a la página de login en 5 segundos.';

    setTimeout(() => {
      window.location.href = '/login.html';
    }, 5000);

  } catch (error) {
    messageParagraph.style.color = 'red';
    messageParagraph.textContent = error.message;
  }
});
